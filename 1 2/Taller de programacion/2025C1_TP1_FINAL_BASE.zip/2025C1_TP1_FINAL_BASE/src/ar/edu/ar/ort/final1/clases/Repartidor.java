// Clase: Repartidor
package ar.edu.ar.ort.final1.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;

public class Repartidor {
	private String id;
	private String nombre;
	private ColaNodos<Pedido> cPedidos;
	private int cantPedidos;

	public Repartidor(String id, String nombre) {
		this.id = id;
		this.nombre = nombre;
		this.cPedidos = new ColaNodos<>();
	}

	public Pedido buscarPedido(int nro) {
		Pedido pedido = null;
		Pedido aux;
		cPedidos.add(null);
		aux = cPedidos.remove();
		while (aux != null) {
			if (aux.esNro(nro)) {
				pedido = aux;
			}
			cPedidos.add(aux);
			aux = cPedidos.remove();
		}
		return pedido;
	}

	// Getters y setters
	public String getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public int cantidadDePedidos() {
		return cantPedidos;
	}

	public void asignarPedido(Pedido pedido) {
		cPedidos.add(pedido);
		cantPedidos++;
	}

}