// Clase: LORepXId
package ar.edu.ar.ort.final1.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ListaOrdenadaNodos;

public class RepartidoresPorID extends ListaOrdenadaNodos<String, Repartidor> {

	@Override
	public int compare(Repartidor repartidor1, Repartidor repartidor2) {
		return compareByKey(repartidor1.getId(), repartidor2);
	}

	@Override
	public int compareByKey(String id, Repartidor repartidor) {
		return id.compareTo(repartidor.getId());
	}

}
