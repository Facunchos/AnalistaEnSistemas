package ar.edu.ar.ort.final1;

import ar.edu.ar.ort.final1.clases.Comercio;
import ar.edu.ar.ort.final1.clases.Repartidor;

public class Test {

	public static void main(String[] args) {
		Comercio negocio = new Comercio();

		// Crear repartidores
		negocio.darElPresente(new Repartidor("R001", "Akira"));
		negocio.darElPresente(new Repartidor("R002", "Naoko"));
		
		// TODO - Agregar un pedido al repartidor menos cargado o al primero que se encuentre sin pedidos.
		int nroDePedido = negocio.hacerPedido("Direccion 1", 1, 1);
		// TODO - Agregar un combo a un pedido preexistente
		negocio.agregarAlPedido(nroDePedido, 3, 1);
		negocio.agregarAlPedido(nroDePedido, 3, 1);
		// TODO - Informar el precio de un pedido
		negocio.informarPrecioPedido(nroDePedido);
		// Agregado de otro pedido
		nroDePedido = negocio.hacerPedido("Direccion 2", 1, 1);
		// TODO - Resolver Warning
		for (int n=1; n < negocio.CAN_COMBOS; n++) {
			negocio.agregarAlPedido(nroDePedido, n, 1);
		}
		negocio.informarPrecioPedido(nroDePedido);
	}

}
