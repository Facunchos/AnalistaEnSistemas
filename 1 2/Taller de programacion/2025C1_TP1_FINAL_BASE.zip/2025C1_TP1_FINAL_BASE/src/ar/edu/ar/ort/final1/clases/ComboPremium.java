// Clase: ComboPremium
package ar.edu.ar.ort.final1.clases;

public class ComboPremium extends Combo {
    private static final double INC_SALSAS = 0.08f;

    private boolean incluyeSalsas;

    public ComboPremium(int nro, String nombre, int canPzas, Dificultad dificultad, boolean incluyeSalsas) {
        super(nro, nombre, canPzas, dificultad);
        this.incluyeSalsas = incluyeSalsas;
    }

    @Override
    public double calcularImporte() {
        double importe = super.calcularImporte();
        if (incluyeSalsas) {
            importe += importe * INC_SALSAS;
        }
        return importe;
    }
}