// Clase: Pedido
package ar.edu.ar.ort.final1.clases;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;

public class Pedido implements Cobrable {
	private int nro;
	private String direccion;
	private PilaNodos<ComboPedido> bolsaDeCombos;

	public Pedido(int nro, String direccion) {
		this.nro = nro;
		this.direccion = direccion;
		this.bolsaDeCombos = new PilaNodos<>();
	}

	@Override
	public double calcularImporte() {
		double total = 0;
		PilaNodos<ComboPedido> pAux = new PilaNodos<>();
		ComboPedido comboPedido;
		while (!bolsaDeCombos.isEmpty()) {
			comboPedido = bolsaDeCombos.pop();
			total += comboPedido.calcularImporte();
			pAux.push(comboPedido);
		}
		while (!pAux.isEmpty()) {
			bolsaDeCombos.push(pAux.pop());
		}
		return total;
	}

	public boolean esNro(int nro) {
		return this.nro == nro;
	}

	// Getters y setters
	public int getNro() {
		return nro;
	}

	public String getDireccion() {
		return direccion;
	}

	public void agregarCombo(Combo combo, int cantidad) {
		// TODO - Modificar. El mismo combo no debe aparecer dos veces en el mismo pedido
		bolsaDeCombos.push(new ComboPedido(cantidad, combo));
	}
}