// Clase: ComboEspecial
package ar.edu.ar.ort.final1.clases;

public class ComboEspecial extends Combo {
	private static final double DTO_SOLOROLL = 0.05;

	private boolean soloRoll;

	public ComboEspecial(int nro, String nombre, int canPzas, Dificultad dificultad, boolean soloRoll) {
		super(nro, nombre, canPzas, dificultad);
		this.soloRoll = soloRoll;
	}

	@Override
	public double calcularImporte() {
		double importe = super.calcularImporte();
		if (soloRoll) {
			importe -= importe * DTO_SOLOROLL;
		}
		return importe;
	}
}