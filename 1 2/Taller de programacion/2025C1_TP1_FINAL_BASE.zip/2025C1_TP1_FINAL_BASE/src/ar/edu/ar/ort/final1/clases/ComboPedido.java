// Clase: ComboPedido
package ar.edu.ar.ort.final1.clases;

public class ComboPedido implements Cobrable {
	private int canPed;
	private Combo combo;

	public ComboPedido(int canPed, Combo combo) {
		this.canPed = canPed;
		this.combo = combo;
	}

	public int getNroCombo() {
		return combo.getNro();
	}

	public int getCanPed() {
		return canPed;
	}

	@Override
	public double calcularImporte() {
		return combo.calcularImporte() * canPed;
	}
}