// Clase: Dificultad
package ar.edu.ar.ort.final1.clases;

public enum Dificultad {
	ALTA(10), MEDIA(15), BAJA(20);

	private final int porcentaje;

	private Dificultad(int porcentaje) {
		this.porcentaje = porcentaje;
	}

	public int getPorcentaje() {
		return porcentaje;
	}
}