// Clase: Combo
package ar.edu.ar.ort.final1.clases;

public abstract class Combo implements Cobrable {
	private static final float VALOR_PZA = 5;

	private int nro;
	private String nombre;
	private int canPzas;
	private Dificultad dificultad;

	public Combo(int nro, String nombre, int canPzas, Dificultad dificultad) {
		this.nro = nro;
		this.nombre = nombre;
		this.canPzas = canPzas;
		this.dificultad = dificultad;
	}

	public double calcularImporte() {
		return canPzas * VALOR_PZA * (100.0 + dificultad.getPorcentaje() / 100);
	}

	public int getNro() {
		return nro;
	}

	public int getCantPiezas() {
		return canPzas;
	}

	public String getNombre() {
		return nombre;
	}
}
