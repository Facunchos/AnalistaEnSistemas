// Clase: Comercio
package ar.edu.ar.ort.final1.clases;

public class Comercio {
	public static final int CAN_COMBOS = 8;

	private Combo[] vCombos;
	private RepartidoresPorID repartidores;
	
	private int _nro_pedido = 1;

	public Comercio() {
		repartidores = new RepartidoresPorID();
		vCombos = new Combo[CAN_COMBOS];
		definirCombos();
	}

	private void definirCombos() {
		vCombos[0] = new ComboEspecial(0, "Especial Solo Roll", 12, Dificultad.BAJA, true);
		vCombos[1] = new ComboEspecial(1, "Especial Maki-Nigiri", 24, Dificultad.MEDIA, false);
		vCombos[2] = new ComboEspecial(2, "Especial Maki-Sashimi-Nigiri", 36, Dificultad.ALTA, false);
		vCombos[3] = new ComboEspecial(3, "Especial Temaki-Sashimi-Inari", 36, Dificultad.ALTA, false);
		vCombos[4] = new ComboPremium(4, "Supermaki Con Salsas", 18, Dificultad.ALTA, true);
		vCombos[5] = new ComboPremium(5, "Supermaki Sin Salsas", 24, Dificultad.MEDIA, false);
		vCombos[6] = new ComboPremium(6, "Variedad Con Salsas", 36, Dificultad.ALTA, false);
		vCombos[7] = new ComboPremium(7, "Variedad Sin Salsas", 24, Dificultad.MEDIA, false);
	}

	public Pedido buscarPedido(int nro) {
		Pedido pedido = null;
		int pos = 0;
		while (pos < repartidores.size() && pedido == null) {
			pedido = repartidores.get(pos).buscarPedido(nro);
			pos++;
		}
		return pedido;
	}

	public void darElPresente(Repartidor repartidor) {
		// TODO - Procesar la carga de repartidores. Debe evitar duplicados.
	}

	public int hacerPedido(String direccion, int nroDeCombo, int cantidad) {
		// TODO desarrollar
		return 0;
	}

	public void agregarAlPedido(int nroDePedido, int nroDeCombo, int cantidad) {
		// TODO desarrollar
	}

	public void informarPrecioPedido(int nroDePedido) {
		// TODO desarrollar
	}

	private double obtenerPrecioDeUnPedido(int nro) {
		double precio = 0;
		Pedido pedido = buscarPedido(nro);
		if (pedido != null)
			precio = pedido.calcularImporte();
		return precio;
	}
	
	/** Genera un nro de pedido nuevo, secuencial, para cada pedido
	 * @return el nuevo nro de pedido
	 */
	private int getProximoNroPedido() {
		int aux = _nro_pedido;
		_nro_pedido++;
		return aux;
	}

}