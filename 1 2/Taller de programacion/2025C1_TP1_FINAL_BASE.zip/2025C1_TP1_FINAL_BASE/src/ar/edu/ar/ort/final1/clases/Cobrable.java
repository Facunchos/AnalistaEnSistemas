// Clase: Cobrable
package ar.edu.ar.ort.final1.clases;

public interface Cobrable {
	double calcularImporte();
}