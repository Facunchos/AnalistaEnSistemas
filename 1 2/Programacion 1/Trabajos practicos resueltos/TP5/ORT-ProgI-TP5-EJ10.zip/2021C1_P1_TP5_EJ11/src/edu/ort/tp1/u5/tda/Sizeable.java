package edu.ort.tp1.u5.tda;

public interface Sizeable {

	int size();

}
